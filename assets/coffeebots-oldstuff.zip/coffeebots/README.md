# THIS IS STILL UNDER DEVELOPMENT AND SHOULD NOT YET BE RUN!

# Coffeebots - A programmable robot war game in CoffeeScript / JavaScript

Coffeebots is a simple 'robot war' game written in CoffeeScript and which can be powered by user-created 'robots' written in
CoffeeScript or JavaScript.

If you're old enough, you might remember [RobotWar](http://en.wikipedia.org/wiki/RobotWar), [Crobots](http://en.wikipedia.org/wiki/Crobots) or PCRobots from the 80s/90s and Coffeebots is along similar lines but not a direct clone. Another modern version is [RoboCode](http://en.wikipedia.org/wiki/RoboCode) in Java.

This project was created at the first [Lincoln Hack](http://ilinkoln.org/lincoln_hack) event on June 18, 2011 as a way for me to learn CoffeeScript.

## Requirements

* A modern browser (only Chrome 12 tested so far)
* Ability to run local Web server to serve scripts

## How To Run

